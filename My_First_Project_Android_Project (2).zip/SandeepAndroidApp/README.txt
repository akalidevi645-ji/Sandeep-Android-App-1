SANDEEP CODE STUDIO - ANDROID WEBVIEW PROJECT

App: My First Project
Package: com.sandeep.my.first.project
Version: 1.0 (1)

BUILD APK
1. Extract this ZIP.
2. Open the SandeepAndroidApp folder in Android Studio.
3. Use JDK 17 and allow Gradle sync to finish.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will be in app/build/outputs/apk/debug/.

Your HTML/CSS/JS project files are in app/src/main/assets/www/.
This ZIP is an Android Studio source project, not an APK file.
