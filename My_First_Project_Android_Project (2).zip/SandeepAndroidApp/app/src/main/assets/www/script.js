document.addEventListener("DOMContentLoaded",function(){
  var demo=document.getElementById("demo");
  var message=document.getElementById("message");
  if(demo&&message){demo.addEventListener("click",function(){message.textContent="Button is working perfectly!";console.log("Demo button clicked");});}
});
console.log("Sandeep Code Studio 8.7 ready");